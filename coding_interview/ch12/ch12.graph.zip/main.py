from DFS import graph

land = graph.Solution()



if __name__ == '__main__':
    print(land.numIslands(
        [["1", "1", "0", "0", "0"], ["1", "1", "0", "0", "0"], ["0", "0", "1", "0", "0"], ["0", "0", "0", "1", "1"]]))

